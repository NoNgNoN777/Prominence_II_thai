---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME Precise Storage Bus
    icon: extendedae:precise_storage_bus
categories:
- extended devices
item_ids:
- extendedae:precise_storage_bus
---

# ME Precise Storage Bus

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_precise_storage_bus.snbt"></ImportStructure>
</GameScene>

ME Precise Storage Bus เป็น <ItemLink id="ae2:storage_bus" /> ที่กำหนดจำนวนในตัวกรองได้ และจะใส่ไอเทมไม่เกินจำนวนที่กำหนด

![GUI](../pic/pre_storage_bus.png)
